namespace MusicLayer.Presentation.Maui;

public sealed class LibrarySongRow : View
{
    public static readonly BindableProperty TrackProperty = BindableProperty.Create(
        nameof(Track), typeof(LibraryTrack), typeof(LibrarySongRow));

    public LibraryTrack? Track
    {
        get => (LibraryTrack?)GetValue(TrackProperty);
        set => SetValue(TrackProperty, value);
    }
}
