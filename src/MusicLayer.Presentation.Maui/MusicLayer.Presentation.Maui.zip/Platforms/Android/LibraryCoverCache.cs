using Android.Graphics;

namespace MusicLayer.Presentation.Maui.Platforms.Android;

// 128 decoded 120px ARGB thumbnails occupy at most about 7 MiB.
internal static class LibraryCoverCache
{
    public const int Capacity = 128;
    private static readonly Dictionary<string, LinkedListNode<(string Path, Bitmap Image)>> entries = new();
    private static readonly LinkedList<(string Path, Bitmap Image)> recent = new();

    public static Bitmap? Find(string path)
    {
        lock (entries)
        {
            if (!entries.TryGetValue(path, out var node)) return null;
            recent.Remove(node);
            recent.AddFirst(node);
            return node.Value.Image;
        }
    }

    public static Bitmap? Load(string path)
    {
        if (Find(path) is { } cached) return cached;
        var image = BitmapFactory.DecodeFile(path);
        if (image is null) return null;
        image.PrepareToDraw();
        lock (entries)
        {
            if (entries.TryGetValue(path, out var existing))
            {
                image.Dispose();
                return existing.Value.Image;
            }
            entries[path] = recent.AddFirst((path, image));
            if (entries.Count > Capacity)
            {
                entries.Remove(recent.Last!.Value.Path);
                recent.RemoveLast(); // A visible ImageView may still own the bitmap.
            }
        }
        return image;
    }
}

