using Android.Content;
using Android.Graphics;
using Android.Graphics.Drawables;
using Android.Text;
using Android.Util;
using Microsoft.Maui.Handlers;
using NativeView = Android.Views.View;
using NativeColor = Android.Graphics.Color;
using Paint = Android.Graphics.Paint;
using Rect = Android.Graphics.Rect;
using RectF = Android.Graphics.RectF;

namespace MusicLayer.Presentation.Maui.Platforms.Android;

internal sealed class LibrarySongRowHandler() : ViewHandler<LibrarySongRow, LibrarySongRowView>(RowMapper)
{
    private static readonly IPropertyMapper<LibrarySongRow, LibrarySongRowHandler> RowMapper =
        new PropertyMapper<LibrarySongRow, LibrarySongRowHandler>(ViewMapper)
        {
            [nameof(LibrarySongRow.Track)] = (handler, view) => handler.PlatformView.Bind(view.Track)
        };

    protected override LibrarySongRowView CreatePlatformView() => new(Context);

    protected override void DisconnectHandler(LibrarySongRowView platformView)
    {
        platformView.Bind(null);
        base.DisconnectHandler(platformView);
    }
}

internal sealed class LibrarySongRowView : NativeView
{
    private readonly float density;
    private readonly Paint surface = new(PaintFlags.AntiAlias) { Color = NativeColor.Rgb(11, 29, 34) };
    private readonly Paint coverBackground = new(PaintFlags.AntiAlias) { Color = NativeColor.Rgb(18, 51, 47) };
    private readonly Paint bitmapPaint = new(PaintFlags.FilterBitmap);
    private readonly TextPaint titlePaint = new(PaintFlags.AntiAlias) { Color = NativeColor.Rgb(242, 248, 247) };
    private readonly TextPaint creditsPaint = new(PaintFlags.AntiAlias) { Color = NativeColor.Rgb(154, 185, 181) };
    private readonly TextPaint formatPaint = new(PaintFlags.AntiAlias) { Color = NativeColor.Rgb(37, 232, 164), TextAlign = Paint.Align.Right };
    private readonly Drawable? fallback;
    private readonly Rect source = new();
    private readonly RectF destination = new();
    private LibraryTrack? track;
    private Bitmap? cover;
    private string title = "";
    private string credits = "";
    private int version;

    public LibrarySongRowView(Context context) : base(context)
    {
        var metrics = context.Resources!.DisplayMetrics!;
        density = metrics.Density;
        titlePaint.SetTypeface(Typeface.DefaultBold);
        titlePaint.TextSize = TypedValue.ApplyDimension(ComplexUnitType.Sp, 15, metrics);
        creditsPaint.TextSize = TypedValue.ApplyDimension(ComplexUnitType.Sp, 13, metrics);
        formatPaint.TextSize = TypedValue.ApplyDimension(ComplexUnitType.Sp, 11, metrics);
        fallback = context.GetDrawable(Resource.Drawable.sixteenth_notes);
        ImportantForAccessibility = global::Android.Views.ImportantForAccessibility.Yes;
    }

    private float Dp(float value) => value * density;

    public void Bind(LibraryTrack? value)
    {
        int request = ++version;
        track = value;
        ContentDescription = value is null ? null : $"{value.Title}, {value.Credits}, {value.Format}";
        UpdateText();

        string? path = value?.ArtworkPath;
        SetCover(path is null ? null : LibraryCoverCache.Find(path));
        if (path is not null && cover is null) _ = LoadCoverAsync(path, request);
    }

    private async Task LoadCoverAsync(string path, int request)
    {
        var bitmap = await Task.Run(() => request == Volatile.Read(ref version) ? LibraryCoverCache.Load(path) : null);
        if (request == version) SetCover(bitmap);
    }

    private void SetCover(Bitmap? bitmap)
    {
        cover = bitmap;
        if (bitmap is not null)
        {
            int size = Math.Min(bitmap.Width, bitmap.Height);
            int x = (bitmap.Width - size) / 2;
            int y = (bitmap.Height - size) / 2;
            source.Set(x, y, x + size, y + size);
        }
        Invalidate();
    }

    protected override void OnMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
        int height = (int)Math.Ceiling(Math.Max(Dp(64), titlePaint.TextSize + creditsPaint.TextSize + Dp(20)));
        SetMeasuredDimension(MeasureSpec.GetSize(widthMeasureSpec), ResolveSize(height, heightMeasureSpec));
    }

    protected override void OnSizeChanged(int w, int h, int oldw, int oldh)
    {
        base.OnSizeChanged(w, h, oldw, oldh);
        float coverTop = (h - Dp(44)) / 2;
        destination.Set(Dp(9), coverTop, Dp(53), coverTop + Dp(44));
        int iconTop = (int)((h - Dp(22)) / 2);
        fallback?.SetBounds((int)Dp(20), iconTop, (int)Dp(42), iconTop + (int)Dp(22));
        UpdateText();
    }

    private void UpdateText()
    {
        float available = Width - Dp(82) - (track is null ? 0 : formatPaint.MeasureText(track.Format));
        title = track is null || available <= 0 ? "" : TextUtils.Ellipsize(track.Title, titlePaint, available, TextUtils.TruncateAt.End!) ?? "";
        credits = track is null || available <= 0 ? "" : TextUtils.Ellipsize(track.Credits, creditsPaint, available, TextUtils.TruncateAt.End!) ?? "";
    }

    protected override void OnDraw(Canvas canvas)
    {
        if (track is null) return;
        canvas.DrawRoundRect(0, 0, Width, Height, Dp(8), Dp(8), surface);
        if (cover is { } bitmap)
            canvas.DrawBitmap(bitmap, source, destination, bitmapPaint);
        else
        {
            canvas.DrawRoundRect(destination, Dp(6), Dp(6), coverBackground);
            fallback?.Draw(canvas);
        }

        float middle = Height / 2f;
        canvas.DrawText(title, Dp(63), middle - Dp(3), titlePaint);
        canvas.DrawText(credits, Dp(63), middle + creditsPaint.TextSize, creditsPaint);
        canvas.DrawText(track.Format, Width - Dp(9), middle - (formatPaint.Ascent() + formatPaint.Descent()) / 2, formatPaint);
    }
}
